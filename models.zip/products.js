class ProductManager {
    constructor() {
        this.products = [
            // Dairy Products
            {
                id: 1,
                name: 'Fresh Milk',
                description: 'Farm-fresh whole milk',
                price: 60,
                expiryDate: '04-08-2025',
                image: 'https://via.placeholder.com/150',
                category: 'Dairy'
            },
            {
                id: 2,
                name: 'Fresh Yogurt',
                description: 'Creamy natural yogurt',
                price: 50,
                expiryDate: '12-04-2024',
                image: 'https://via.placeholder.com/150',
                category: 'Dairy'
            },
            {
                id: 3,
                name: 'Fresh Cheese',
                description: 'Artisanal cheddar cheese',
                price: 120,
                expiryDate: '20-04-2024',
                image: 'https://via.placeholder.com/150',
                category: 'Dairy'
            },
            {
                id: 4,
                name: 'Fresh Butter',
                description: 'Pure dairy butter',
                price: 90,
                expiryDate: '25-04-2024',
                image: 'https://via.placeholder.com/150',
                category: 'Dairy'
            },
            {
                id: 5,
                name: 'Cottage Cheese',
                description: 'Fresh paneer',
                price: 80,
                expiryDate: '15-04-2024',
                image: 'https://via.placeholder.com/150',
                category: 'Dairy'
            },

            // Bakery Products
            {
                id: 6,
                name: 'Fresh Bread',
                description: 'Freshly baked whole wheat bread',
                price: 40,
                expiryDate: '08-04-2024',
                image: 'https://via.placeholder.com/150',
                category: 'Bakery'
            },
            {
                id: 7,
                name: 'Croissants',
                description: 'Buttery French croissants',
                price: 60,
                expiryDate: '09-04-2024',
                image: 'https://via.placeholder.com/150',
                category: 'Bakery'
            },
            {
                id: 8,
                name: 'Muffins',
                description: 'Assorted fresh muffins',
                price: 45,
                expiryDate: '09-04-2024',
                image: 'https://via.placeholder.com/150',
                category: 'Bakery'
            },

            // Fruits
            {
                id: 9,
                name: 'Fresh Apples',
                description: 'Fresh, juicy apples from local orchards',
                price: 120,
                expiryDate: '08-04-2025',
                image: 'https://via.placeholder.com/150',
                category: 'Fruits'
            },
            {
                id: 10,
                name: 'Bananas',
                description: 'Ripe yellow bananas',
                price: 40,
                expiryDate: '15-04-2024',
                image: 'https://via.placeholder.com/150',
                category: 'Fruits'
            },
            {
                id: 11,
                name: 'Oranges',
                description: 'Sweet and juicy oranges',
                price: 80,
                expiryDate: '20-04-2024',
                image: 'https://via.placeholder.com/150',
                category: 'Fruits'
            },

            // Vegetables
            {
                id: 12,
                name: 'Fresh Tomatoes',
                description: 'Vine-ripened tomatoes',
                price: 40,
                expiryDate: '12-04-2024',
                image: 'https://via.placeholder.com/150',
                category: 'Vegetables'
            },
            {
                id: 13,
                name: 'Spinach',
                description: 'Fresh organic spinach',
                price: 30,
                expiryDate: '10-04-2024',
                image: 'https://via.placeholder.com/150',
                category: 'Vegetables'
            },
            {
                id: 14,
                name: 'Carrots',
                description: 'Fresh organic carrots',
                price: 35,
                expiryDate: '15-04-2024',
                image: 'https://via.placeholder.com/150',
                category: 'Vegetables'
            },

            // Meat & Poultry
            {
                id: 15,
                name: 'Fresh Chicken',
                description: 'Farm-fresh whole chicken',
                price: 180,
                expiryDate: '09-04-2024',
                image: 'https://via.placeholder.com/150',
                category: 'Meat & Poultry'
            },
            {
                id: 16,
                name: 'Fresh Eggs',
                description: 'Farm-fresh organic eggs',
                price: 80,
                expiryDate: '15-04-2024',
                image: 'https://via.placeholder.com/150',
                category: 'Meat & Poultry'
            },
            {
                id: 17,
                name: 'Fish Fillet',
                description: 'Fresh fish fillet',
                price: 220,
                expiryDate: '08-04-2024',
                image: 'https://via.placeholder.com/150',
                category: 'Meat & Poultry'
            }
        ];
        this.cart = new Cart();
        this.init();
    }

    init() {
        this.displayProducts();
        this.setupEventListeners();
    }

    displayProducts() {
        const container = document.getElementById('products-container');
        if (!container) return;

        // Group products by category
        const groupedProducts = this.products.reduce((acc, product) => {
            if (!acc[product.category]) {
                acc[product.category] = [];
            }
            acc[product.category].push(product);
            return acc;
        }, {});

        // Create HTML for each category
        let html = '';
        for (const [category, products] of Object.entries(groupedProducts)) {
            html += `
                <div class="category-section">
                    <h2 class="category-title">${category}</h2>
                    <div class="products-grid">
                        ${products.map(product => this.createProductCard(product)).join('')}
                    </div>
                </div>
            `;
        }

        container.innerHTML = html;
    }

    createProductCard(product) {
        return `
            <div class="product-card" data-id="${product.id}">
                <img src="${product.image}" alt="${product.name}">
                <h3>${product.name}</h3>
                <p>${product.description}</p>
                <p class="price">₹${product.price}</p>
                <p class="expiry">Expires: ${product.expiryDate}</p>
                <button class="add-to-cart-btn" onclick="productManager.addToCart(${product.id})">
                    Add to Cart
                </button>
            </div>
        `;
    }

    setupEventListeners() {
        document.addEventListener('click', (e) => {
            if (e.target.classList.contains('add-to-cart-btn')) {
                const productId = parseInt(e.target.closest('.product-card').dataset.id);
                this.addToCart(productId);
            }
        });
    }

    addToCart(productId) {
        const product = this.products.find(p => p.id === productId);
        if (product) {
            this.cart.addItem(product);
            this.updateCartCount();
            alert(`${product.name} added to cart!`);
        }
    }

    updateCartCount() {
        const cartCount = document.getElementById('cart-count');
        if (cartCount) {
            cartCount.textContent = this.cart.items.length;
        }
    }
}

// Initialize the product manager when the DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.productManager = new ProductManager();
}); 